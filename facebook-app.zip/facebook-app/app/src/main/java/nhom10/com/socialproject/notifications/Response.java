package nhom10.com.socialproject.notifications;

public class Response {
    private String success;
}
